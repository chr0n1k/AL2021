<?php 
/**
 * YITH plugin integration
 *
 * @author      UX Themes
 * @package     Flatsome/Integrations
 */