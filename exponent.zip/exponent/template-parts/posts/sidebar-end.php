    </div>
    <div class="be-col" >
    <?php get_sidebar(); ?>
    </div>
    </div>
    </div>
