v1.2.9.2
======
* Fixed: Php8 wanings
* Fixed: Demo settings Import

v1.2.9.1
======
* Fixed: Tatsu white screen
* Fixed: Spaces in empty search

v1.2.9.0
======
* Fixed: Auto scroll for large touch screen
* Fixed: Newsletter Subscribe 

v1.2.8.9
======
* Fixed: bugs

v1.2.8.8
======
* Fixed: woocommerce view cart page for multiple cross sale products
* Fixed: woocommerce template update
* Fixed: tatsu freeze bug