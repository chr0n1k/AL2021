<?php 
Be_Options::add_config(array(
  'capability'        => 'edit_theme_options',
  'option_type'       => 'theme_mod'
));