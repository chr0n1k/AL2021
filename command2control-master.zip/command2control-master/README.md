# Command & Control Server + Agent

Command & Control is a controller server with one or multiple agents spread around the network connected to it. Its purpose is to have a centralized server in which one attacker can queue up commands for each agent to execute automatically and then see the output.

Each agent spawns and sends the server information about itself, to then start waiting and polling each number of seconds for commands to execute.

The server exposes GET+Post endpoints to control the flow of the entire structure.

To learn how to use this please refer to [the documentation](https://docs.cyberranges.com/doc/commandcontrol-SEmO54waW1)
