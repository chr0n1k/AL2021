#!/bin/python3

import os
import sys

if os.geteuid() == 0:
    print("Please do not execute this script as root.")
    sys.exit(-1)

systemd_service_file_contents = ""
with open("systemd_service_file", mode="r", encoding="utf8") as template:
    systemd_service_file_contents = template.read()

home_dir = os.path.expanduser("~")
cwd_project_root = os.path.dirname(os.path.realpath(__file__))
server_script = f"{cwd_project_root}/server.py"

systemd_service_file_contents = systemd_service_file_contents.format(exec_path=server_script)

os.makedirs(f"{home_dir}/.config/systemd/user/", exist_ok=True)
with open(f"{home_dir}/.config/systemd/user/c2c.service", mode="w", encoding="utf8") as f:
    f.write(systemd_service_file_contents)

print(f"The c2c service was installed on {home_dir}/.config/systemd/user/c2c.service.")
print("Please enable the service by running: systemctl --user enable c2c")
print("Then start the server by running: systemctl --user start c2c")
print(f"To remove the server stop it and then run: rm {home_dir}/.config/systemd/user/c2c.service")
